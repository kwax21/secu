# -*- coding: utf-8 -*
from random import randint
import sys

#Fonction récupéré
def pgcd(e,phiN) :  
	#Tant que le reste de la division n'est pas 0, on continu à diviser pour avoir le PGCD
	while e%phiN != 0 : 
		e, phiN = phiN, e%phiN 
	return phiN

def initialisation():
	
	print("\n\n******************************")
	print("Fonction de d'initialisation")
	print("******************************")
	
	#Déterminer p et q
	p = 401
	q = 827
	
	print("p = " + str(p))
	print("q = " + str(q))
	
	#Calcul de n
	n = p*q
	
	print("n = " + str(n))
	
	#Calcul de PHI(n)
	phiN = (p-1)*(q-1)
	
	print("phiN = " + str(phiN))
	

	#Déterminer e :
	e=randint(0,3000000
	stop=0
	while stop == 0:
		#Il faut que e soit inférieur à phiN et que e et phiN soit premier entre eux
		if (pgcd(e,phiN)==1) :
			stop = 1
		else :
			e = randint(0,3000000)
		
	print("e = " + str(e))
	
	#Calcul de d
	d=0
	cpt = 0
	while cpt == 0:
		#Il faut que d soit supérieur à p et q et inférieur à phiN
		#Il faut que le calcul e * d % phiN soit égale à 1
		if((e * d % phiN == 1)and(p < d)and(q < d)and(d < phiN)):
			cpt = 1
		#elif(d > phiN):
			#print("ERROR")
		else :
			d = d + 1

	print("d = " + str(d))
	
	#On retourne les couples (e,n) pour le chiffrage et (d,n) pour le déchiffrage
	return (e, d, n);
	
def decrypt(c,d,n) :
	
	print("\n\n******************************")
	print("Fonction de déchiffrage")
	print("******************************")
	
	#Déchiffrage du message C
	m = c**d%n
	
	print("Le message crypté : " + str(c))
	print("le message décrypté : " + str(m))


print("\n\n******************************")
print("Programme RSA")
print("******************************")

e, d, n = initialisation()
if len(sys.argv) == 1:
	print("\n\n\n")
	print("Donner à l'autre utilisateur :")
	print("e = " + str(e))
	print("n = " + str(n))
else:
	messC = sys.argv[1]
	decrypt(int(messC),d,n)

