# -*- coding: utf-8 -*
import sys

def premier(n):
	
	#Si n égale 1 ou 2 il est premier
	if n == 1 or n == 2:
		return True
		
	#Si n est pair il n'est pas premier
	if n%2 == 0:
		return False
	
	r = n**0.5
	
	#Si n a une racine il n'est pas premier
	if r == int(r):
		return False
	#S'il est divisible il n'est pas premier
	for x in range(3, int(r), 2):
		if n % x == 0:
			return False	
	
	return True
	
def crack(e,n):
	#Déterminer p et q
	p = 2
	q = 2
	stop = 0
	stop2 = 0
	while stop != 1 :
		#Pour calculer p on cherche un nombre premier qui divise n
		if (premier(p) == True)and(n%p == 0):
			nTMP = n/p
			print("p = " + str(p))
			print("nTMP = " + str(nTMP))
			#Pour calculer q on cherche un nombre premier qui divise n/p
			while stop2 != 1 :
				if (premier(q) == True)and(nTMP%q == 0):
					stop2 = 1
				else :
					q = q+1
			stop = 1
		else :
			p = p+1
	
	print("q = " + str(q))
	
	#Calcule de phiN
	phiN = (p-1)*(q-1)
	
	print("phiN = " + str(phiN))
	
	#Calcule de d 
	d=0
	cpt = 0
	while cpt == 0:
		#Il faut que d soit supérieur à p et q et inférieur à phiN
		#Il faut que le calcul e * d % phiN soit égale à 1
		if((e * d % phiN == 1)and(p < d)and(q < d)and(d < phiN)):
			cpt = 1
		else :
			d = d + 1

	print("d = " + str(d))
	
	return (d,n);
	
def decrypt(c,d,n) :
	
	print("\n\n******************************")
	print("Fonction de déchiffrage")
	print("******************************")
	
	timeD = time.clock()
	#Déchiffrage du message C
	m = c**d%n
	timeF = time.clock()
	print("Le message crypté : " + str(c))
	print("le message décrypté : " + str(m))
	print("Temps pour crypter : " + str(timeF-timeD) + " secondes")

if len(sys.argv) != 4 :
	print("relancer le programme en mettant en argument : le message chiffré puis e puis n")
else :
	d, n = crack(int(sys.argv[2]),int(sys.argv[3]));
	decrypt(int(sys.argv[1]),d,n)
