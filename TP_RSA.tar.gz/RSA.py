# -*- coding: utf-8 -*
from random import randint
import time

#Fonction récupérée
def pgcd(e,phiN) :  
	#Tant que le reste de la division n'est pas 0, on continu à diviser pour avoir le PGCD
	while e%phiN != 0 : 
		e, phiN = phiN, e%phiN 
	return phiN
   
#Fonction en partie récupérée (pour la dernière condition)
def premier(n):
	
	#Si n égale 1 ou 2 il est premier
	if n == 1 or n == 2:
		return True
		
	#Si n est pair il n'est pas premier
	if n%2 == 0:
		return False
	
	r = n**0.5
	
	#Si n a une racine il n'est pas premier
	if r == int(r):
		return False
	#S'il est divisible il n'est pas premier
	for x in range(3, int(r), 2):
		if n % x == 0:
			return False	
	
	return True
	
def calcul_bloc(m,n):
	
	print("\n\n******************************")
	print("Fonction de calcul des blocs à chiffrer")
	print("******************************")
	
	bloc = []
	for i in range(len(m)):
		bloc.append(ord(m[i]))
	stop = 0
	i = 1
	taille = []
	while stop !=1:
		j=1
		while (int(str(bloc[i-1]) + str(bloc[i])) < int(n))and(i+1 < len(bloc)):
			if(i < len(bloc)):
				j = j+1
				bloc[i-1] = str(bloc[i-1]) + str(bloc[i])
				del bloc[i]
		if (i+1 == len(bloc)) :
			stop = 1
		if (int(str(bloc[i-1]) + str(bloc[i])) > int(n)):
			taille.append(j)
		i = i + 1
		
	if int(str(bloc[i-2]) + str(bloc[i-1])) < int(n):
		bloc[i-2] = str(bloc[i-2]) + str(bloc[i-1])
		del bloc[i-1]
		j= j+1
		taille.append(j)
	
	k = len(bloc)-1
	if(len(str(bloc[k])) == 2)or(len(str(bloc[k])) == 3):
		taille.append(1)
	print(taille)
	print(bloc)
	
	return bloc,taille;

def initialisation():
	
	print("\n\n******************************")
	print("Fonction de d'initialisation")
	print("******************************")
	
	#Déterminer p et q
	p = randint(3,3000);
	q = randint(3,3000);
	
	#on prend un nombre aléatoire, tant qu'il n'est pas premier, on retire
	while premier(p)== False:
		p = randint(3,3000);
	
	while premier(q)== False:
		q = randint(3,3000);
	
	print("p = " + str(p))
	print("q = " + str(q))
	
	#Calcul de n
	n = p*q
	
	print("n = " + str(n))
	
	#Calcul de PHI(n)
	phiN = (p-1)*(q-1)
	
	print("phiN = " + str(phiN))
	

	#Déterminer e :
	e=randint(1,30000)
	stop=0
	while stop == 0:
		#Il faut que e soit inférieur à phiN et que e et phiN soit premier entre eux
		if (pgcd(e,phiN)==1) :
			stop = 1
		else :
			e = randint(1,30000)
		
	print("e = " + str(e))
	
	#Calcul de d
	d=0
	cpt = 0
	while cpt == 0:
		#Il faut que d soit supérieur à p et q et inférieur à phiN
		#Il faut que le calcul e * d % phiN soit égale à 1
		if((e * d % phiN == 1)and(p < d)and(q < d)and(d < phiN)):
			cpt = 1
		#elif(d > phiN):
			#print("ERROR")
		else :
			d = d + 1

	print("d = " + str(d))
	
	#On retourne les couples (e,n) pour le chiffrage et (d,n) pour le déchiffrage
	return (e, d, n);
	
	
def crypt(m,e,n):
	
	print("\n\n******************************")
	print("Fonction de chiffrage")
	print("******************************")
	
	c = []
	timeD = time.clock()
	#Chiffrage du message m
	for i in range(len(m)):
		tmp=int(m[i])**e%n
		c.append(int(tmp))
	timeF = time.clock()
	
	print("Le message a crypter : " + str(m))
	print("le message crypté : " + str(c))
	print("Temps pour crypter : " + str(timeF-timeD) + " secondes")
	
	return c ;
	
def decrypt(c,taille,d,n) :
	
	print("\n\n******************************")
	print("Fonction de déchiffrage")
	print("******************************")
	
	m = []
	timeD = time.clock()
	#Déchiffrage du message C
	for i in range(len(c)):
		tmp = int(c[i])**d%n
		m.append(int(tmp))
	timeF = time.clock()
	
	for i in range(len(m)):
		tmp = m[i]
		tmp = str(tmp)
		if (taille[i] == 1):
			print(chr(int(tmp)))
		elif((taille[i] == 2)and(len(tmp) == 5)):
			print(chr(int(tmp[0:3])))
			print(chr(int(tmp[3:5])))
		elif((taille[i] == 2)and(len(tmp) == 6)):
			print(chr(int(tmp[0:3])))
			print(chr(int(tmp[3:5])))
	
	print("Le message crypté : " + str(c))
	print("le message décrypté : " + str(m))
	print("Temps pour crypter : " + str(timeF-timeD) + " secondes")


print("\n\n******************************")
print("Programme RSA")
print("******************************")

e, d, n = initialisation()
m = raw_input("Donnez un message à chiffrer : ");
bloc,taille = calcul_bloc(m,n)
c = crypt(bloc,e,n)

decrypt(c,taille,d,n)
